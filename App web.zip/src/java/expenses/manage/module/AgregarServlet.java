package expenses.manage.module;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AgregarServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/agendatelefonica"; // Cambia a tu DB
    private static final String DB_USER = "root"; // Cambia a tu usuario
    private static final String DB_PASSWORD = "Admin$1234"; // Cambia a tu contraseña

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String action = request.getParameter("action");

        try (PrintWriter out = response.getWriter()) {
            if ("submit".equals(action)) {
                // Obtener datos del formulario
                String nombre = request.getParameter("txtnombre");
                String telefono = request.getParameter("txttelefono");
                String email = request.getParameter("txtemail");
                String direccion = request.getParameter("txtdireccion");

                // Conexión a la base de datos
                try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                    String sql = "INSERT INTO contactos (nombre, telefono, email, direccion) VALUES (?, ?, ?, ?)";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        
                         out.println("<html><head><title>Contactos</title>");
            out.println("<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'>");
            out.println("<style> body { padding: 20px; } </style>");
            out.println("</head><body>");
            out.println("<h1>Lista de Contactos</h1>");
            out.println("<table class='table table-bordered'>");
            out.println("<thead class='thead-dark'><tr><th>ID</th><th>Nombre</th><th>Teléfono</th><th>Email</th><th>Dirección</th></tr></thead>");
            out.println("<tbody>");
                        
                        
                        
                        pstmt.setString(1, nombre);
                        pstmt.setString(2, telefono);
                        pstmt.setString(3, email);
                        pstmt.setString(4, direccion);
                        pstmt.executeUpdate();
                        out.println("<h2>Contacto agregado exitosamente</h2>");
                        out.println("</tbody>");
                        out.println("</table>");
                        out.println("<form action='expensesServlet' method='get'>");
                        out.println("<button type='submit' class='btn btn-primary'>Volver a lista</button>");
                        out.println("<a href='index.html' class='btn btn-danger'>Volver a Login</a>");
                        out.println("</body></html>");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    out.println("<h2>Error al agregar el contacto</h2>");
                }
            } else {
                // Si no es submit, muestra el formulario
                out.println("<!DOCTYPE html>");
                out.println("<html lang='es'>");
                out.println("<head>");
                out.println("<meta charset='UTF-8'>");
                out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
                out.println("<title>Agregar Contacto</title>");
                out.println("<link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'>");
                out.println("</head>");
                out.println("<body>");
                out.println("<div class='container mt-5'>");
                out.println("<h1 class='text-center'>Agregar Contacto</h1>");
                out.println("<form action='AgregarServlet' method='post' class='form'>");
                out.println("<input type='hidden' name='action' value='submit'/>"); // Para distinguir la acción
                out.println("<div class='form-group'>");
                out.println("<label for='txtnombre'>Nombre:</label>");
                out.println("<input type='text' name='txtnombre' id='txtnombre' class='form-control' required/>");
                out.println("</div>");
                out.println("<div class='form-group'>");
                out.println("<label for='txttelefono'>Teléfono:</label>");
                out.println("<input type='text' name='txttelefono' id='txttelefono' class='form-control' required/>");
                out.println("</div>");
                out.println("<div class='form-group'>");
                out.println("<label for='txtemail'>Email:</label>");
                out.println("<input type='email' name='txtemail' id='txtemail' class='form-control' required/>");
                out.println("</div>");
                out.println("<div class='form-group'>");
                out.println("<label for='txtdireccion'>Dirección:</label>");
                out.println("<input type='text' name='txtdireccion' id='txtdireccion' class='form-control' required/>");
                out.println("</div>");
                out.println("<button type='submit' class='btn btn-primary btn-block'>Agregar Contacto</button>");
                out.println("</form>");
                out.println("<br/>");
                out.println("<a href='index.html' class='btn btn-danger btn-block'>Volver a Login</a>");
                out.println("</div>");
                out.println("</body>");
                out.println("</html>");
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Servlet para agregar contactos";

    }
}

















































































/*package expenses.manage.module;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AgregarServlet extends HttpServlet {
     Connection conn;
    private static final String DB_URL = "jdbc:mysql://localhost:3306/agendatelefonica"; // Cambia a tu DB
    private static final String DB_USER = "root"; // Cambia a tu usuario
    private static final String DB_PASSWORD = "Admin$1234"; // Cambia a tu contraseña

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html lang='es'>");
            out.println("<head>");
            out.println("<meta charset='UTF-8'>");
            out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
            out.println("<title>Agregar Contacto</title>");
            out.println("<link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'>");
            out.println("</head>");
            out.println("<body>");
            out.println("<div class='container mt-5'>");
            out.println("<h1 class='text-center'>Agregar Contacto</h1>");
            out.println("<form action='AgregarContactoServlet' method='post' class='form'>");
            out.println("<div class='form-group'>");
            out.println("<label for='txtnombre'>Nombre:</label>");
            out.println("<input type='text' name='txtnombre' id='txtnombre' class='form-control' required/>");
            out.println("</div>");
            out.println("<div class='form-group'>");
            out.println("<label for='txttelefono'>Teléfono:</label>");
            out.println("<input type='text' name='txttelefono' id='txttelefono' class='form-control' required/>");
            out.println("</div>");
            out.println("<div class='form-group'>");
            out.println("<label for='txtemail'>Email:</label>");
            out.println("<input type='email' name='txtemail' id='txtemail' class='form-control' required/>");
            out.println("</div>");
            out.println("<div class='form-group'>");
            out.println("<label for='txtdireccion'>Dirección:</label>");
            out.println("<input type='text' name='txtdireccion' id='txtdireccion' class='form-control' required/>");
            out.println("</div>");
            out.println("<button type='submit' class='btn btn-primary btn-block'>Agregar Contacto</button>");
            out.println("</form>");
            out.println("<br/>");
            out.println("<a href='index.html' class='btn btn-danger btn-block'>Volver a Login</a>");
            out.println("</div>");
            out.println("</body>");
            out.println("</html>");
            
          //conecta a agenda
          // Obtener datos del formulario
            String nombre = request.getParameter("txtnombre");
            String telefono = request.getParameter("txttelefono");
            String email = request.getParameter("txtemail");
            String direccion = request.getParameter("txtdireccion");
 
            // Conexión a la base de datos
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                String sql = "INSERT INTO contactos (nombre, telefono, email, direccion) VALUES (?, ?, ?, ?)";
                try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                    pstmt.setString(1, nombre);
                    pstmt.setString(2, telefono);
                    pstmt.setString(3, email);
                    pstmt.setString(4, direccion);
                    pstmt.executeUpdate();
                }
            } catch (Exception e) {
                e.printStackTrace();
                out.println("<h2>Error al agregar el contacto</h2>");
                return;
            }
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
*/
