package expenses.manage.module;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class EliminarServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/agendatelefonica"; // Cambia a tu DB
    private static final String DB_USER = "root"; // Cambia a tu usuario
    private static final String DB_PASSWORD = "Admin$1234"; // Cambia a tu contraseña

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String action = request.getParameter("action");

        try (PrintWriter out = response.getWriter()) {
            if ("submit".equals(action)) {
                // Obtener datos del formulario
                String id = request.getParameter("txtid");

                // Conexión a la base de datos
                try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                    String sql = "DELETE FROM contactos WHERE id = ?"; // Asegúrate de que el nombre de la tabla sea correcto
                    
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setString(1, id); // Establecer el parámetro
                        int rowsAffected = pstmt.executeUpdate(); // Ejecutar la actualización

                        out.println("<html><head><title>Eliminar Contactos</title>");
                        out.println("<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'>");
                        out.println("<style> body { padding: 20px; } </style>");
                        out.println("</head><body>");
                        out.println("<h1>Eliminar contacto</h1>");
                        out.println("<table class='table table-bordered'>");
                        out.println("<tbody>");

                        if (rowsAffected > 0) {
                            out.println("<h2>Contacto eliminado exitosamente</h2>");
                        } else {
                            out.println("<h2>No se encontró un contacto con el ID proporcionado</h2>");
                        }

                        out.println("</tbody>");
                        out.println("</table>");
                        out.println("<form action='expensesServlet' method='get'>");
                        out.println("<button type='submit' class='btn btn-primary'>Volver a lista</button>");
                        out.println("<a href='index.html' class='btn btn-danger'>Volver a Login</a>");
                        out.println("</form>");
                        out.println("</body></html>");
                    }
                } catch (Exception e) {
                    out.println("<h2>Error al eliminar el contacto. Por favor, inténtalo de nuevo.</h2>");
                    // Puedes registrar el error en logs en lugar de imprimirlo aquí
                }
            } else {
                // Si no es submit, muestra el formulario
                out.println("<html><head><title>Eliminar Contacto</title>");
                out.println("<link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'>");
                out.println("</head><body>");
                out.println("<div class='container mt-5'>");
                out.println("<h1 class='text-center'>Eliminar Contacto</h1>");
                out.println("<form action='EliminarServlet' method='post' class='form'>");
                out.println("<input type='hidden' name='action' value='submit'/>"); // Para distinguir la acción
                out.println("<div class='form-group'>");
                out.println("<label for='txtid'>ID:</label>");
                out.println("<input type='text' name='txtid' id='txtid' class='form-control' required/>");
                out.println("</div>");
                out.println("<button type='submit' class='btn btn-primary'>Eliminar Contacto</button>");
                out.println("</form>");
                out.println("<br/>");
                out.println("<a href='index.html' class='btn btn-danger'>Volver a Login</a>");
                out.println("</div>");
                out.println("</body></html>");
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Servlet para eliminar contactos";
    }
}

