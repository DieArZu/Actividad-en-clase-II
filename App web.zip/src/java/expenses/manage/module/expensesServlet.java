package expenses.manage.module;

import expenses.database.module.databaseHelper;
import expenses.models.module.User;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class expensesServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        try (PrintWriter out = response.getWriter()) {
            databaseHelper dbHelper = new databaseHelper();
            ResultSet resultset = dbHelper.getExpenses(0); // Llama a tu método que obtiene los datos

            out.println("<html><head><title>Contactos</title>");
            out.println("<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'>");
            out.println("<style> body { padding: 20px; } </style>");
            out.println("</head><body>");
            out.println("<h1>Lista de Contactos</h1>");
            out.println("<table class='table table-bordered'>");
            out.println("<thead class='thead-dark'><tr><th>ID</th><th>Nombre</th><th>Teléfono</th><th>Email</th><th>Dirección</th></tr></thead>");
            out.println("<tbody>");

            /* Formulario para agregar un nuevo contacto
            out.println("<h2>Agregar Contacto</h2>");
            out.println("<form action='AgregarContactoServlet' method='post' class='form-group'>");
            out.println("<label>Nombre:</label> <input type='text' name='txtnombre' class='form-control' required/><br/>");
            out.println("<label>Teléfono:</label> <input type='text' name='txttelefono' class='form-control' required/><br/>");
            out.println("<label>Email:</label> <input type='email' name='txtemail' class='form-control' required/><br/>");
            out.println("<label>Dirección:</label> <input type='text' name='txtdireccion' class='form-control' required/><br/>");
            //out.println("<input type='submit' class='btn btn-primary' value='Agregar Contacto'/>");
            out.println("</form><br/>");*/
            // Iterar a través del ResultSet
            while (resultset.next()) {
                int id = resultset.getInt("id");
                String nombre = resultset.getString("nombre");
                String telefono = resultset.getString("telefono");
                String email = resultset.getString("email");
                String direccion = resultset.getString("direccion");

                // Imprimir los datos en una tabla HTML
                out.println("<tr>");
                out.println("<td>" + id + "</td>");
                out.println("<td>" + nombre + "</td>");
                out.println("<td>" + telefono + "</td>");
                out.println("<td>" + email + "</td>");
                out.println("<td>" + direccion + "</td>");
                out.println("</tr>");
            }



            out.println("</tbody>");
            out.println("</table>");

// Formulario para agregar contacto
            out.println("<form action='AgregarServlet' method='get'>");
            out.println("<button type='submit' class='btn btn-primary'>Agregar Contacto</button>");
            out.println("</form>"); // Cierra el formulario de agregar contacto

// Formulario para eliminar contacto
            out.println("<form action='EliminarServlet' method='post'>"); // Cambiado a 'post' si se necesita
            out.println("<button type='submit' class='btn btn-danger'>Eliminar Contacto</button>");
            out.println("</form>"); // Cierra el formulario de eliminar contacto

            out.println("<a href='index.html' class='btn btn-danger'>Volver a Login</a>");
            out.println("</body></html>");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
